avrdude.exe -C avrdude.conf -v -v -v -p m2560 -carduino -P\\.\COM7 -b115200 -D -Uflash:w:owsilprog_v008_m2560_16mhz_pb3pb4.hex


avrdude.exe -C avrdude.conf -v -v -v -pm2560 -cstk500v2 -P\\.\COM7 -b115200 -D -Uflash:w:owsilprog_v008_m2560_16mhz_pb3pb4.hex
