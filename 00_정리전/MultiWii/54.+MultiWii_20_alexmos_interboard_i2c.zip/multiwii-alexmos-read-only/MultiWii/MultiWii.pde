/*
MultiWiiCopter by Alexandre Dubus
www.multiwii.com
March  2012     V2.0
 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 any later version. see <http://www.gnu.org/licenses/>
*/

#include "config.h"
#include "def.h"
#include <avr/pgmspace.h>
#define  VERSION  20
// alexmos
#include "OpticalFlow.h"
#include "Sonar.h"

/*********** RC alias *****************/
#define ROLL       0
#define PITCH      1
#define YAW        2
#define THROTTLE   3
#define AUX1       4
#define AUX2       5
#define AUX3       6
#define AUX4       7

#define PIDALT     3
#define PIDVEL     4
#define PIDGPS     5
#define PIDLEVEL   6
#define PIDMAG     7

#define BOXACC       0
#define BOXBARO      1
#define BOXMAG       2
#define BOXCAMSTAB   3
#define BOXCAMTRIG   4
#define BOXARM       5
#define BOXGPSHOME   6
#define BOXGPSHOLD   7
#define BOXPASSTHRU  8
#define BOXHEADFREE  9
#define BOXBEEPERON  10

#define CHECKBOXITEMS 11
#define PIDITEMS 8


//////////////////////////////////////////////////////////////////////////////////////////
#ifdef BLCTRL_MOT
static uint32_t blctrlTime;
#endif

//static uint8_t armed = 0;
static uint8_t scheduler = 0;
//////////////////////////////////////////////////////////////////////////////////////////////////////////



static uint32_t currentTime = 0;
static uint16_t previousTime = 0;
static uint16_t cycleTime = 0;     // this is the number in micro second to achieve a full loop, it can differ a little and is taken into account in the PID loop
static uint16_t cycleCnt = 0;
static uint16_t calibratingA = 0;  // the calibration is done is the main loop. Calibrating decreases at each cycle down to 0, then we enter in a normal mode.
static uint8_t  calibratingM = 0;
static uint16_t calibratingG;
static uint8_t  armed = 0;
static uint16_t acc_1G;             // this is the 1G measured acceleration
static int16_t  acc_25deg;
static uint8_t  nunchuk = 0;
static uint8_t  accMode = 0;        // if level mode is a activated
static uint8_t  magMode = 0;        // if compass heading hold is a activated
static uint8_t  baroMode = 0;       // if altitude hold is activated
static uint8_t  GPSModeHome = 0;    // if GPS RTH is activated
static uint8_t  GPSModeHold = 0;    // if GPS PH is activated
static uint8_t  headFreeMode = 0;   // if head free mode is a activated
static uint8_t  passThruMode = 0;   // if passthrough mode is activated
static int16_t  headFreeModeHold;
static int16_t  gyroADC[3],accADC[3],accSmooth[3],magADC[3];
static int16_t  accTrim[2] = {0, 0};
static int16_t  heading,magHold;
static uint8_t  calibratedACC = 0;
static uint8_t  vbat;               // battery voltage in 0.1V steps
static uint8_t  okToArm = 0;
static uint8_t  rcOptions[CHECKBOXITEMS];
static int32_t  BaroAlt;
static int32_t	BaroAltGround; // baro for 'ground level'
static int32_t  EstVelocity;
static int32_t  EstAlt;             // in cm
static uint8_t  buzzerState = 0;
  
//for log
static uint16_t cycleTimeMax = 0;       // highest ever cycle timen
static uint16_t cycleTimeMin = 65535;   // lowest ever cycle timen
static uint16_t powerMax = 0;           // highest ever current

static int16_t  i2c_errors_count = 0;
static int16_t  annex650_overrun_count = 0;

static int16_t debug1=0 , debug2=0, debug3=0, debug4=0;

// **********************
//Automatic ACC Offset Calibration
// **********************
static uint16_t InflightcalibratingA = 0;
static int16_t AccInflightCalibrationArmed;
static uint16_t AccInflightCalibrationMeasurementDone = 0;
static uint16_t AccInflightCalibrationSavetoEEProm = 0;
static uint16_t AccInflightCalibrationActive = 0;

// **********************
// power meter
// **********************
#define PMOTOR_SUM 8                     // index into pMeter[] for sum
static uint32_t pMeter[PMOTOR_SUM + 1];  // we use [0:7] for eight motors,one extra for sum
static uint8_t pMeterV;                  // dummy to satisfy the paramStruct logic in ConfigurationLoop()
static uint32_t pAlarm;                  // we scale the eeprom value from [0:255] to this value we can directly compare to the sum in pMeter[6]
static uint8_t powerTrigger1 = 0;        // trigger for alarm based on power consumption
static uint16_t powerValue = 0;          // last known current
static uint16_t intPowerMeterSum, intPowerTrigger1;

// **********************
// telemetry
// **********************
static uint8_t telemetry = 0;
static uint8_t telemetry_auto = 0;

// ******************
// rc functions
// ******************
#if !defined(MINCHECK)
	#define MINCHECK 1100
#endif
#if !defined(MAXCHECK)
	#define MAXCHECK 1900
#endif


volatile int16_t failsafeCnt = 0;
static int16_t failsafeEvents = 0;
static int16_t rcData[8];    // interval [1000;2000]
static int16_t rcCommand[4]; // interval [1000;2000] for THROTTLE and [-500;+500] for ROLL/PITCH/YAW 
static uint8_t rcRate8;
static uint8_t rcExpo8;
static int16_t lookupRX[7]; //  lookup table for expo & RC rate
volatile uint8_t rcFrameComplete; //for serial rc receiver Spektrum


// **************
// gyro+acc IMU
// **************
static int16_t gyroData[3] = {0,0,0};
static int16_t gyroZero[3] = {0,0,0};
static int16_t accZero[3]  = {0,0,0};
static uint16_t accScale[3]  = {0,0,0};  // sensivity correction (1000 for acc_1G)
static int16_t magZero[3]  = {0,0,0};
static int16_t angle[2]    = {0,0};  // absolute angle inclination in multiple of 0.1 degree    180 deg = 1800
static int8_t  smallAngle25 = 1;

// *************************
// motor and servo functions
// *************************
static int16_t axisPID[3];
static int16_t motor[8];
static int16_t servo[8] = {1500,1500,1500,1500,1500,1500,1500,1500};
static uint16_t wing_left_mid  = WING_LEFT_MID; 
static uint16_t wing_right_mid = WING_RIGHT_MID; 
static uint16_t tri_yaw_middle = TRI_YAW_MIDDLE; 

// **********************
// EEPROM & LCD functions
// **********************
static uint8_t P8[8], I8[8], D8[8]; // 8 bits is much faster and the code is much shorter
static uint8_t dynP8[3], dynI8[3], dynD8[3];
static uint8_t rollPitchRate;
static uint8_t yawRate;
static uint8_t dynThrPID;
static uint8_t activate1[CHECKBOXITEMS];
static uint8_t activate2[CHECKBOXITEMS];

// **********************
// GPS
// **********************
static int32_t  GPS_latitude,GPS_longitude;
static int32_t  GPS_latitude_home,GPS_longitude_home;
static int32_t  GPS_latitude_hold,GPS_longitude_hold;
static uint8_t  GPS_fix , GPS_fix_home = 0;
static uint8_t  GPS_numSat;
static uint16_t GPS_distanceToHome,GPS_distanceToHold;       // distance to home or hold point in meters
static int16_t  GPS_directionToHome,GPS_directionToHold;     // direction to home or hol point in degrees
static uint16_t GPS_altitude,GPS_speed;                      // altitude in 0.1m and speed in 0.1m/s - Added by Mis
static uint8_t  GPS_update = 0;                              // it's a binary toogle to distinct a GPS position update
static int16_t  GPS_angle[2];                                // it's the angles that must be applied for GPS correction



// alexmos
static int8_t cosZ = 100; // cos(angleZ)*100
static int16_t throttleAngleCorrection = 0; // correction oh throttle in lateral wind
static uint8_t  buzzerFreq;         //delay between buzzer ring



///////////////////////////////////////////////////////////////////////////////////////

uint8_t BLCTRL_I2C[4] = {0x54, 0x56, 0x58, 0x52};//{0x52,0x54, 0x56, 0x58};

static uint8_t i2c_motor[4] = {0, 0, 0, 0};
///////////////////////////////////////////////////////////////////////////////////////




void blinkLED(uint8_t num, uint8_t wait,uint8_t repeat) {
  uint8_t i,r;
  for (r=0;r<repeat;r++) {
    for(i=0;i<num;i++) {
      LEDPIN_TOGGLE; //switch LEDPIN state
      BUZZERPIN_ON;
      delay(wait);
      BUZZERPIN_OFF;
    }
    delay(60);
  }
}

void annexCode() { // this code is excetuted at each loop and won't interfere with control loop if it lasts less than 650 microseconds
  static uint32_t buzzerTime,calibratedAccTime;
  #if defined(LCD_TELEMETRY)
   static uint16_t telemetryTimer = 0, telemetryAutoTimer = 0, psensorTimer = 0;
  #endif
  #if defined(LCD_TELEMETRY_AUTO)
   static uint8_t telemetryAutoIndex = 0;
   static char telemetryAutoSequence []  = LCD_TELEMETRY_AUTO;
  #endif
  #ifdef VBAT
    static uint8_t vbatTimer = 0;
  #endif
  uint8_t axis,prop1,prop2;
  #if defined(POWERMETER_HARD)
    uint16_t pMeterRaw;               // used for current reading
  #endif

  // PITCH & ROLL only dynamic PID adjustemnt,  depending on throttle value
  if      (rcData[THROTTLE]<1500) prop2 = 100;
  else if (rcData[THROTTLE]<2000) prop2 = 100 - (uint16_t)dynThrPID*(rcData[THROTTLE]-1500)/500;
  else                            prop2 = 100 - dynThrPID;

  for(axis=0;axis<3;axis++) {
    uint16_t tmp = min(abs(rcData[axis]-MIDRC),500);
    #if defined(DEADBAND)
      if (tmp>DEADBAND) { tmp -= DEADBAND; }
      else { tmp=0; }
    #endif
    if(axis!=2) { //ROLL & PITCH
      uint16_t tmp2 = tmp/100;
      rcCommand[axis] = lookupRX[tmp2] + (tmp-tmp2*100) * (lookupRX[tmp2+1]-lookupRX[tmp2]) / 100;
      prop1 = 100-(uint16_t)rollPitchRate*tmp/500;
      prop1 = (uint16_t)prop1*prop2/100;
    } else { //YAW
      rcCommand[axis] = tmp;
      prop1 = 100-(uint16_t)yawRate*tmp/500;
    }
    dynP8[axis] = (uint16_t)P8[axis]*prop1/100;
    dynD8[axis] = (uint16_t)D8[axis]*prop1/100;
    if (rcData[axis]<MIDRC) rcCommand[axis] = -rcCommand[axis];
  }

  /* alexmos: Throttle expo curve */
  #ifdef THROTTLE_EXPO
    uint16_t tmp;
    /* map x=[MINCHECK..SHIFT_HOVER..MAXCHECK] to [0..500] (expo without rcRate) */
    if(rcData[THROTTLE] < SHIFT_HOVER) {
      tmp = 500 - (uint32_t)(max(rcData[THROTTLE], MINCHECK) - MINCHECK)*500/(SHIFT_HOVER - MINCHECK);
    } else {
      tmp = (uint32_t)(min(rcData[THROTTLE], MAXCHECK) - SHIFT_HOVER)*500/(MAXCHECK - SHIFT_HOVER);
    }
    uint16_t tmp2 = tmp/100;
    uint16_t y = (lookupRX[tmp2]*50 + (tmp-tmp2*100) * (lookupRX[tmp2+1]-lookupRX[tmp2]) / 2 ) / rcRate8;

    /* map y=[0..500] to [MINTHROTTLE..THROTTLE_HOVER..MAXTHROTTLE] */
    if (rcData[THROTTLE] < SHIFT_HOVER) {
      rcCommand[THROTTLE] = MINTHROTTLE + (uint32_t)(500-y) * (THROTTLE_HOVER - MINTHROTTLE) / 500;
    } else {
      rcCommand[THROTTLE] = THROTTLE_HOVER + (uint32_t) y * (MAXTHROTTLE - THROTTLE_HOVER) / 500;
    }
  #else
	  rcCommand[THROTTLE] = MINTHROTTLE + (int32_t)(MAXTHROTTLE-MINTHROTTLE)* (rcData[THROTTLE]-MINCHECK)/(2000-MINCHECK);
	#endif

  if(headFreeMode) {
    float radDiff = (heading - headFreeModeHold) * 0.0174533f; // where PI/180 ~= 0.0174533
    float cosDiff = cos(radDiff);
    float sinDiff = sin(radDiff);
    int16_t rcCommand_PITCH = rcCommand[PITCH]*cosDiff + rcCommand[ROLL]*sinDiff;
    rcCommand[ROLL] =  rcCommand[ROLL]*cosDiff - rcCommand[PITCH]*sinDiff; 
    rcCommand[PITCH] = rcCommand_PITCH;
  }

  #if defined(POWERMETER_HARD)
    if (! (++psensorTimer % PSENSORFREQ)) {
     pMeterRaw =  analogRead(PSENSORPIN);
     powerValue = ( PSENSORNULL > pMeterRaw ? PSENSORNULL - pMeterRaw : pMeterRaw - PSENSORNULL); // do not use abs(), it would induce implicit cast to uint and overrun
     if ( powerValue < 333) {  // only accept reasonable values. 333 is empirical
     #ifdef LOG_VALUES
        if (powerValue > powerMax) powerMax = powerValue;
     #endif
     } else {
        powerValue = 333;
     }        
     pMeter[PMOTOR_SUM] += (uint32_t) powerValue;
  }
  #endif

  if (buzzerFreq) {
    if (buzzerState && (currentTime > buzzerTime + 250000) ) {
      buzzerState = 0;
      BUZZERPIN_OFF;
      buzzerTime = currentTime;
    } else if ( !buzzerState && (currentTime > (buzzerTime + (2000000>>buzzerFreq))) ) {
      buzzerState = 1;
      BUZZERPIN_ON;
      buzzerTime = currentTime;
    }
  } else if(buzzerState) {
  	buzzerState = 0; BUZZERPIN_OFF;
  }

  #if defined(VBAT)
    static uint8_t ind = 0;
    uint16_t vbatRaw = 0;
    static uint16_t vbatRawArray[8];
    if (! (++vbatTimer % VBATFREQ)) {
    	vbatRawArray[(ind++)%8] = analogRead(V_BATPIN);
    	for (uint8_t i=0;i<8;i++) vbatRaw += vbatRawArray[i];
    	vbat = vbatRaw / (VBATSCALE/2);                  // result is Vbatt in 0.1V steps
    }
    if ( rcOptions[BOXBEEPERON] || failsafeCnt > (5*FAILSAVE_DELAY)){ // unconditional beeper on via AUXn switch + alexmos: beep in filesafe
       buzzerFreq = 7;
    } else  if ( ( (vbat>VBATLEVEL1_3S) 
    #if defined(POWERMETER)
                         && ( (pMeter[PMOTOR_SUM] < pAlarm) || (pAlarm == 0) )
    #endif
                       )  || (NO_VBAT>vbat)                              ) // ToLuSe
    {                                          // VBAT ok AND powermeter ok, buzzer off
      buzzerFreq = 0; 
    #if defined(POWERMETER)
    } else if (pMeter[PMOTOR_SUM] > pAlarm) {                             // sound alarm for powermeter
      buzzerFreq = 4;
    #endif
    } else if (vbat>VBATLEVEL2_3S) buzzerFreq = 1;
    else if (vbat>VBATLEVEL3_3S)   buzzerFreq = 2;
    else                           buzzerFreq = 4;
  #endif

  if ( (calibratingA>0 && (ACC || nunchuk) ) || (calibratingG>0) ) {  // Calibration phasis
    LEDPIN_TOGGLE;
  } else {
    if (calibratedACC == 1) {LEDPIN_OFF;}
    // alexmos: blink LED when bipping
    if (armed && !buzzerState) {LEDPIN_ON;}
  }

  #if defined(LED_RING)
    static uint32_t LEDTime;
    if ( currentTime > LEDTime ) {
      LEDTime = currentTime + 50000;
      i2CLedRingState();
    }
  #endif

  if ( currentTime > calibratedAccTime ) {
    if (smallAngle25 == 0) {
      calibratedACC = 0; // the multi uses ACC and is not calibrated or is too much inclinated
      LEDPIN_TOGGLE;
      calibratedAccTime = currentTime + 500000;
    } else
      calibratedACC = 1;
  }

  serialCom();

  #if defined(POWERMETER)
    intPowerMeterSum = (pMeter[PMOTOR_SUM]/PLEVELDIV);
    intPowerTrigger1 = powerTrigger1 * PLEVELSCALE; 
  #endif

  #ifdef LCD_TELEMETRY_AUTO
    if ( (telemetry_auto) && (! (++telemetryAutoTimer % LCD_TELEMETRY_AUTO_FREQ) )  ){
      telemetry = telemetryAutoSequence[++telemetryAutoIndex % strlen(telemetryAutoSequence)];
      LCDclear(); // make sure to clear away remnants
    }
  #endif  
  #ifdef LCD_TELEMETRY
    if (! (++telemetryTimer % LCD_TELEMETRY_FREQ)) {
      #if (LCD_TELEMETRY_DEBUG+0 > 0)
        telemetry = LCD_TELEMETRY_DEBUG;
      #endif
      if (telemetry) lcd_telemetry();
    }
  #endif
  
  #if GPS
    static uint32_t GPSLEDTime;
    if ( currentTime > GPSLEDTime && (GPS_fix_home == 1)) {
      GPSLEDTime = currentTime + 150000;
      LEDPIN_TOGGLE;
    }
  #endif
}


void setup() {
  SerialOpen(0,SERIAL_COM_SPEED);
  LEDPIN_PINMODE;
  POWERPIN_PINMODE;
  BUZZERPIN_PINMODE;
  STABLEPIN_PINMODE;
  POWERPIN_OFF;
  initOutput();
  readEEPROM();
  checkFirstTime();
  configureReceiver();
  initSensors();
  
  //alexmos: init sonar
  #if defined(SONAR)
  	initSonar();
  #endif
  
  #if defined(OPTFLOW)
  	initOptflow();
  #endif
  
  //alexmos: wait 1 seconds before start calibrating
  delay(1000);
  previousTime = micros();
  #if defined(GIMBAL)
   calibratingA = 400;
  #endif
  calibratingG = 400;
  #if defined(POWERMETER)
    for(uint8_t i=0;i<=PMOTOR_SUM;i++)
      pMeter[i]=0;
  #endif
  #if defined(GPS_SERIAL)
    SerialOpen(GPS_SERIAL,GPS_BAUD);
  #endif
  #if defined(LCD_ETPP)
    initLCD();
  #elif defined(LCD_LCD03)
    initLCD();
  #endif
  #ifdef LCD_TELEMETRY_DEBUG
    telemetry_auto = 1;
  #endif
  #ifdef LCD_CONF_DEBUG
    configurationLoop();
  #endif
  ADCSRA |= _BV(ADPS2) ; ADCSRA &= ~_BV(ADPS1); ADCSRA &= ~_BV(ADPS0); // this speeds up analogRead without loosing too much resolution: http://www.arduino.cc/cgi-bin/yabb2/YaBB.pl?num=1208715493/11
}

 

//////////////////////////////////////////////////////////////////////////////////////////////////
// ******** Main Loop *********
void loop () {
   if (currentTime > (blctrlTime + 1000 ) ) { // 1000=1000 Hz, 2000=500 Hz
    blctrlTime = currentTime;
    if (scheduler == 0) {
      interboard_i2c_motors();
    } else {
      //i2c_Gyro_getADC();
      Gyro_getADC();
    }
    scheduler = 1 - scheduler;
  }
  mainloop();
  
}


void interboard_i2c_motors() {
    #ifdef BLCTRL_MOT
  if (armed==1) { //f.ARMED ) {
      for(uint8_t i=0;i<min(NUMBER_MOTOR,4);i++) {   // [1000;2000] => [0;255]
        i2c_rep_start(BLCTRL_I2C[i]); // Send command to Ctrl 
        i2c_write(i2c_motor[i]);   // Set speed of Ctrl   
      }
  }
  #endif
}

//////////////////////////////////////////////////////////////////////////////////////////////////




// ******** Main Loop *********
void mainloop () {
  static uint8_t rcDelayCommand; // this indicates the number of time (multiple of RC measurement at 50Hz) the sticks must be maintained to run or switch off motors
  uint8_t axis,i;
  int16_t error,errorAngle;
  int16_t delta,deltaSum;
  int16_t PTerm,ITerm,DTerm;
  static int16_t lastGyro[3] = {0,0,0};
  static int16_t delta1[3],delta2[3];
  static int16_t errorGyroI[3] = {0,0,0};
  static int16_t errorAngleI[2] = {0,0};
  static uint32_t rcTime  = 0;
  static int16_t initialThrottleHold;
  static int32_t errorAltitudeI = 0;
  static int16_t AltHold;
  static int16_t AltHoldCorr = 0, magHoldCorr = 0;
  int16_t AltPID;
  
  cycleCnt++;
 
  #if defined(SPEKTRUM)
    if (rcFrameComplete) computeRC();
  #endif

  if (currentTime > rcTime ) { // 50Hz
    rcTime = currentTime + 20000;
    #if !(defined(SPEKTRUM) ||defined(BTSERIAL))
      computeRC();
    #endif
    // Failsafe routine - added by MIS
    #if defined(FAILSAFE)
      if ( failsafeCnt > (5*FAILSAVE_DELAY) && armed==1) {                  // Stabilize, and set Throttle to specified level
        for(i=0; i<3; i++) rcData[i] = MIDRC;                               // after specified guard time after RC signal is lost (in 0.1sec)
        rcData[THROTTLE] = FAILSAVE_THR0TTLE;
        if (failsafeCnt > 5*(FAILSAVE_DELAY+FAILSAVE_OFF_DELAY)) {          // Turn OFF motors after specified Time (in 0.1sec)
          armed = 0;   // This will prevent the copter to automatically rearm if failsafe shuts it down and prevents
          okToArm = 0; // to restart accidentely by just reconnect to the tx - you will have to switch off first to rearm
        }
        failsafeEvents++;
      }
      failsafeCnt++;
    #endif
    // end of failsave routine - next change is made with RcOptions setting
    if (rcData[THROTTLE] < MINCHECK) {
      errorGyroI[ROLL] = 0; errorGyroI[PITCH] = 0; errorGyroI[YAW] = 0;
      errorAngleI[ROLL] = 0; errorAngleI[PITCH] = 0;
      rcDelayCommand++;
      if (rcData[YAW] < MINCHECK && rcData[PITCH] < MINCHECK && armed == 0) {
        if (rcDelayCommand == 20) calibratingG=400;
      } else if (rcData[YAW] > MAXCHECK && rcData[PITCH] > MAXCHECK && armed == 0) {
        if (rcDelayCommand == 20) {
          #ifdef TRI
            servo[5] = 1500; // we center the yaw servo in conf mode
            writeServos();
          #endif
          #ifdef FLYING_WING
            servo[0]  = wing_left_mid;
            servo[1]  = wing_right_mid;
            writeServos();
          #endif
          #if defined(LCD_CONF)
            configurationLoop(); // beginning LCD configuration
          #endif
          previousTime = micros();
        }
      }
      #if defined(InflightAccCalibration)  
        else if (armed == 0 && rcData[YAW] < MINCHECK && rcData[PITCH] > MAXCHECK && rcData[ROLL] > MAXCHECK){
          if (rcDelayCommand == 20){
            if (AccInflightCalibrationMeasurementDone){                // trigger saving into eeprom after landing
              AccInflightCalibrationMeasurementDone = 0;
              AccInflightCalibrationSavetoEEProm = 1;
            }else{ 
              AccInflightCalibrationArmed = !AccInflightCalibrationArmed; 
              if (AccInflightCalibrationArmed){blinkLED(10,1,2);}else{blinkLED(10,10,3);} 
            }
          }
       } 
     #endif
      else if ((activate1[BOXARM] > 0) || (activate2[BOXARM] > 0)) {
        if ( rcOptions[BOXARM] && okToArm ) {
          armed = 1;
          BaroAltGround = BaroAlt;
          headFreeModeHold = heading;
        } else if (armed) armed = 0;
        rcDelayCommand = 0;
      } else if ( (rcData[YAW] < MINCHECK || rcData[ROLL] < MINCHECK)  && armed == 1) {
        if (rcDelayCommand == 20) armed = 0; // rcDelayCommand = 20 => 20x20ms = 0.4s = time to wait for a specific RC command to be acknowledged
      } else if ( (rcData[YAW] > MAXCHECK || rcData[ROLL] > MAXCHECK) && rcData[PITCH] < MAXCHECK && armed == 0 && calibratingG == 0 && calibratedACC == 1) {
        if (rcDelayCommand == 20) {
          armed = 1;
          BaroAltGround = BaroAlt;
          headFreeModeHold = heading;
        }
     #ifdef LCD_TELEMETRY_AUTO
      } else if (rcData[ROLL] < MINCHECK && rcData[PITCH] > MAXCHECK && armed == 0) {
        if (rcDelayCommand == 20) {
           if (telemetry_auto) {
              telemetry_auto = 0;
              telemetry = 0;
           } else
              telemetry_auto = 1;
        }
     #endif
      } else
        rcDelayCommand = 0;
    } else if (rcData[THROTTLE] > MAXCHECK && armed == 0) {
      if (rcData[YAW] < MINCHECK && rcData[PITCH] < MINCHECK) {        // throttle=max, yaw=left, pitch=min
        if (rcDelayCommand == 20) calibratingA=400;
        rcDelayCommand++;
      } else if (rcData[YAW] > MAXCHECK && rcData[PITCH] < MINCHECK) { // throttle=max, yaw=right, pitch=min  
        if (rcDelayCommand == 20) calibratingM=1; // MAG calibration request
        rcDelayCommand++;
      } else if (rcData[PITCH] > MAXCHECK) {
         accTrim[PITCH]+=2;writeParams();
         #if defined(LED_RING)
           blinkLedRing();
         #endif
      } else if (rcData[PITCH] < MINCHECK) {
         accTrim[PITCH]-=2;writeParams();
         #if defined(LED_RING)
           blinkLedRing();
         #endif
      } else if (rcData[ROLL] > MAXCHECK) {
         accTrim[ROLL]+=2;writeParams();
         #if defined(LED_RING)
           blinkLedRing();
         #endif
      } else if (rcData[ROLL] < MINCHECK) {
         accTrim[ROLL]-=2;writeParams();
         #if defined(LED_RING)
           blinkLedRing();
         #endif
      } else {
        rcDelayCommand = 0;
      }
    }
   #ifdef LOG_VALUES
    if (cycleTime > cycleTimeMax) cycleTimeMax = cycleTime; // remember highscore
    if (cycleTime < cycleTimeMin) cycleTimeMin = cycleTime; // remember lowscore
   #endif

    #if defined(InflightAccCalibration)  
      if (AccInflightCalibrationArmed && armed == 1 && rcData[THROTTLE] > MINCHECK && !rcOptions[BOXARM] ){ // Copter is airborne and you are turning it off via boxarm : start measurement
        InflightcalibratingA = 50;
        AccInflightCalibrationArmed = 0;  
      }  
      if (rcOptions[BOXPASSTHRU]) {      // Use the Passthru Option to activate : Passthru = TRUE Meausrement started, Land and passtrhu = 0 measurement stored
        if (!AccInflightCalibrationActive && !AccInflightCalibrationMeasurementDone){
          InflightcalibratingA = 50;
        }
      }else if(AccInflightCalibrationMeasurementDone && armed == 0){
        AccInflightCalibrationMeasurementDone = 0;
        AccInflightCalibrationSavetoEEProm = 1;
      }
    #endif

    for(i=0;i<CHECKBOXITEMS;i++) {
      rcOptions[i] = (
      ( (rcData[AUX1]<1300)    | (1300<rcData[AUX1] && rcData[AUX1]<1700)<<1 | (rcData[AUX1]>1700)<<2
       |(rcData[AUX2]<1300)<<3 | (1300<rcData[AUX2] && rcData[AUX2]<1700)<<4 | (rcData[AUX2]>1700)<<5) & activate1[i]
      )||(
      ( (rcData[AUX3]<1300)    | (1300<rcData[AUX3] && rcData[AUX3]<1700)<<1 | (rcData[AUX3]>1700)<<2
       |(rcData[AUX4]<1300)<<3 | (1300<rcData[AUX4] && rcData[AUX4]<1700)<<4 | (rcData[AUX4]>1700)<<5) & activate2[i]);
    }
    
    // note: if FAILSAFE is disable, failsafeCnt > 5*FAILSAVE_DELAY is always false
    if (( rcOptions[BOXACC] || (failsafeCnt > 5*FAILSAVE_DELAY) ) && (ACC || nunchuk)) { 
      // bumpless transfer to Level mode
      if (!accMode) {
        errorAngleI[ROLL] = 0; errorAngleI[PITCH] = 0;
        accMode = 1;
      }  
    } else accMode = 0;  // modified by MIS for failsave support

    if (rcOptions[BOXARM] == 0) okToArm = 1;
    if (accMode == 1) {STABLEPIN_ON;} else {STABLEPIN_OFF;}

    #if BARO
      if (rcOptions[BOXBARO]) {
        if (baroMode == 0) {
          baroMode = 1;
          AltHold = EstAlt;
          initialThrottleHold = rcCommand[THROTTLE];
          errorAltitudeI = 0;
        }
      } else baroMode = 0;
    #endif
    #if MAG
      if (rcOptions[BOXMAG]) {
        if (magMode == 0) {
          magMode = 1;
          magHold = heading;
        }
      } else magMode = 0;
      if (rcOptions[BOXHEADFREE]) {
        if (headFreeMode == 0) {
          headFreeMode = 1;
        }
      } else headFreeMode = 0;
    #endif
    #if GPS
      if (rcOptions[BOXGPSHOME]) {GPSModeHome = 1;}
      else GPSModeHome = 0;
      if (rcOptions[BOXGPSHOLD]) {
        if (GPSModeHold == 0) {
          GPSModeHold = 1;
          GPS_latitude_hold = GPS_latitude;
          GPS_longitude_hold = GPS_longitude;
        }
      } else {
        GPSModeHold = 0;
      }
    #endif
    // alexmos: using GPSHold checkbox for opticalFlow mode, because no special box in GUI
    #if defined(OPTFLOW)
      if (rcOptions[BOXGPSHOLD]) {optflowMode = 1;}
      else optflowMode = 0;
    #endif
    if (rcOptions[BOXPASSTHRU]) {passThruMode = 1;}
    else passThruMode = 0;
  } else { // not in rc loop
    static int8_t taskOrder=0; // never call all functions in the same loop, to avoid high delay spikes
    switch (taskOrder) {
      case 0:
        taskOrder++;    
        #if MAG
          Mag_getADC();
          break;
        #endif
      case 1:
        taskOrder++; 
        #if BARO
          Baro_update();     
          break;
        #endif
      case 2:
        taskOrder++; 
        #if BARO
          getEstimatedAltitude();
          break;
        #endif
      case 3:
        taskOrder++; 
        #if GPS
          GPS_NewData();
          break;
        #endif
      case 4:
        taskOrder++; 
        #ifdef OPTFLOW
        	Optflow_update();
          break;
        #endif
      default:
        taskOrder=0;
        break;
    }
  }

  computeIMU();
  // Measure loop rate just afer reading the sensors
  currentTime = micros();
  cycleTime = currentTime - previousTime;
  previousTime = currentTime;

  #if MAG
    if (abs(rcCommand[YAW]) <70 && magMode) {
      int16_t dif = heading - magHold;
      if (dif <= - 180) dif += 360;
      else if (dif >= + 180) dif -= 360;
      if ( smallAngle25 ) rcCommand[YAW] -= dif*P8[PIDMAG]/30;  // 18 deg
    } else magHold = heading;
    
    
    // alexmos: improved heading correction
    /*
    if (magMode) {
    	magHoldCorr+= rcCommand[YAW];
    	if(abs(magHoldCorr) > 1000) {
    		magHold+= magHoldCorr/1000;
    		magHoldCorr%= 1000;
		    if (magHold <= - 180) magHold += 360;
		    else if (magHold >= + 180) magHold -= 360;
    	}
      
      if ( smallAngle25 ) {
	      int16_t dif = heading - magHold;
	      if (dif <= - 180) dif += 360;
	      else if (dif >= + 180) dif -= 360;
      	rcCommand[YAW] = dif*P8[PIDMAG]/30;
      }
    }*/
    	
  #endif

  #if BARO
    if (baroMode) {
      // Throttle stick moved? 
      if (abs(rcCommand[THROTTLE]-initialThrottleHold) > ALT_HOLD_DEADBAND) {
      	// Slowly increase AltHold proportional to stick movement ( +100 throttle gives ~ +20 cm in 1 second)
      	AltHoldCorr+= rcCommand[THROTTLE] - initialThrottleHold;
      	if(abs(AltHoldCorr) > 1000) {
      		AltHold+= AltHoldCorr/1000;
      		AltHoldCorr%= 1000;
      	}
        buzzerFreq = 1; // beep buzzer 1Hz
      } 

      //alexmos: new Alt PID's calculations
      if(cosZ > 50) { // apply Alt correction only if inclination angle < 60 (skip in aerobatics)
	      error = constrain( AltHold - EstAlt, -150, 150); //  +/-1.5m, if more - something wrong
	      errorAltitudeI += error;
	      errorAltitudeI = constrain(errorAltitudeI, -1000000, 1000000); 
	      
	      // Apply deadband for P-term and baro only
	      #ifdef BARO_DEADBAND
	      	if(!SONAR_USED) {
			      if(error > BARO_DEADBAND) error-= BARO_DEADBAND;
			      else if(error < -BARO_DEADBAND) error+= BARO_DEADBAND;
			      else error = 0;
			    }
		    #endif
	      
	      // Increase P-term if sonar is used
	      #if defined(SONAR) && defined(SONAR_BARO_PID_GAIN)
	      	if(SONAR_USED) {
	      		int16_t tmp = error * (SONAR_ERROR_MAX - SonarErrors) / SONAR_ERROR_MAX * SONAR_BARO_PID_GAIN;
	      		error+=  constrain(tmp, -150, 150);
	      	}
	      #endif
	      
	      
	      // AltPID = PTerm - DTerm + ITerm
	      AltPID = P8[PIDALT] * error / 50 - D8[PIDALT] * constrain(EstVelocity, -150, 150) / 10  // 16 bit ok: 200 * 150 = 30000
	      					+ (int16_t)(I8[PIDALT] * errorAltitudeI / 100000);

	      rcCommand[THROTTLE] = initialThrottleHold + constrain(AltPID, -200, 200);

	      // Debug PID controller to GUI
	      #ifdef ALT_DEBUG
	        debug4 = AltPID * 10;
	      #endif
	    } 
    }
  #endif


  // alexmos: Gain throttle in case of inclination (only in stable mode)
  #if THROTTLE_ANGLE_CORRECTION > 0
  	if(accMode == 1 && cosZ > 0) {
	  	rcCommand[THROTTLE]+= throttleAngleCorrection;
	  }
	#endif

  #if GPS
    uint16_t GPS_dist;
    int16_t  GPS_dir;

    if ( (GPSModeHome == 0 && GPSModeHold == 0) || (GPS_fix_home == 0) ) {
      GPS_angle[ROLL]  = 0;
      GPS_angle[PITCH] = 0;
    } else {
      if (GPSModeHome == 1) {
        GPS_dist = GPS_distanceToHome;
        GPS_dir = GPS_directionToHome;
      }
      if (GPSModeHold == 1) {
        GPS_dist = GPS_distanceToHold;
        GPS_dir = GPS_directionToHold;
      }
      float radDiff = (GPS_dir-heading) * 0.0174533f;
      GPS_angle[ROLL]  = constrain(P8[PIDGPS] * sin(radDiff) * GPS_dist / 10,-D8[PIDGPS]*10,+D8[PIDGPS]*10); // with P=5.0, a distance of 1 meter = 0.5deg inclination
      GPS_angle[PITCH] = constrain(P8[PIDGPS] * cos(radDiff) * GPS_dist / 10,-D8[PIDGPS]*10,+D8[PIDGPS]*10); // max inclination = D deg
    }
  #endif

  //**** PITCH & ROLL & YAW PID ****    
  for(axis=0;axis<3;axis++) {
    if (accMode == 1 && axis<2 ) { //LEVEL MODE
      // 50 degrees max inclination
      int16_t tmp = 2*rcCommand[axis] - GPS_angle[axis];
      errorAngle = constrain(tmp,-500,+500) - angle[axis] + accTrim[axis]; //16 bits is ok here
      #ifdef OPTFLOW
      	errorAngle-= optflow_angle[axis];
      #endif
      
      #ifdef LEVEL_PDF
        PTerm      = -(int32_t)angle[axis]*P8[PIDLEVEL]/100 ;
      #else  
        PTerm      = (int32_t)errorAngle*P8[PIDLEVEL]/100 ;                          // 32 bits is needed for calculation: errorAngle*P8[PIDLEVEL] could exceed 32768   16 bits is ok for result
      #endif
      PTerm = constrain(PTerm,-D8[PIDLEVEL]*5,+D8[PIDLEVEL]*5);

      errorAngleI[axis]  = constrain(errorAngleI[axis]+errorAngle,-10000,+10000);    // WindUp     //16 bits is ok here
      ITerm              = ((int32_t)errorAngleI[axis]*I8[PIDLEVEL])>>12;            // 32 bits is needed for calculation:10000*I8 could exceed 32768   16 bits is ok for result
    } else { //ACRO MODE or YAW axis
      if (abs(rcCommand[axis])<350) error =          rcCommand[axis]*10*8/P8[axis] ; // 16 bits is needed for calculation: 350*10*8 = 28000      16 bits is ok for result if P8>2 (P>0.2)
                               else error = (int32_t)rcCommand[axis]*10*8/P8[axis] ; // 32 bits is needed for calculation: 500*5*10*8 = 200000   16 bits is ok for result if P8>2 (P>0.2)
      error -= gyroData[axis];

      PTerm = rcCommand[axis];
      
      errorGyroI[axis]  = constrain(errorGyroI[axis]+error,-16000,+16000);          // WindUp   16 bits is ok here
      if (abs(gyroData[axis])>640) errorGyroI[axis] = 0;
      ITerm = (errorGyroI[axis]/125*I8[axis])>>6;                                   // 16 bits is ok here 16000/125 = 128 ; 128*250 = 32000
    }
    if (abs(gyroData[axis])<160) PTerm -=          gyroData[axis]*dynP8[axis]/10/8; // 16 bits is needed for calculation   160*200 = 32000         16 bits is ok for result
                            else PTerm -= (int32_t)gyroData[axis]*dynP8[axis]/10/8; // 32 bits is needed for calculation   

    if(axis < 2) { // except YAW axis, because it's correction very slow
      delta          = gyroData[axis] - lastGyro[axis];                               // 16 bits is ok here, the dif between 2 consecutive gyro reads is limited to 800
      lastGyro[axis] = gyroData[axis];
      deltaSum       = delta1[axis]+delta2[axis]+delta;
      delta2[axis]   = delta1[axis];
      delta1[axis]   = delta;
 
      if (abs(deltaSum)<640) DTerm = (deltaSum*dynD8[axis])>>5;                       // 16 bits is needed for calculation 640*50 = 32000           16 bits is ok for result 
                      else DTerm = ((int32_t)deltaSum*dynD8[axis])>>5;              // 32 bits is needed for calculation
    } else {
        DTerm = 0;
    }
                      
    axisPID[axis] =  PTerm + ITerm - DTerm;
  }

  mixTable();
  writeServos();
  writeMotors();
}
